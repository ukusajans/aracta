package com.aracta.app;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Tüm Android sürümlerinde aynı görünüm: içerik durum ve gezinme çubuklarının arkasına uzanır,
        // boşlukları Capacitor SystemBars (safe-area) yönetir.
        EdgeToEdge.enable(this);
    }
}
