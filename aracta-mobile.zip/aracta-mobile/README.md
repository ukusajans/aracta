# Araçta — iOS ve Android uygulaması (Capacitor 8)

Uygulama canlı siteyi (`https://aracta.com.tr`) açar. Sitede yaptığınız güncellemeler **mağaza onayı beklemeden** uygulamalara da yansır.
Bu klasörü yeniden derlemeniz yalnızca bu klasördeki dosyalar (ikon, izin, eklenti, sürüm) değiştiğinde gerekir.

Telefonda devreye giren yerel özellikler:
- **Bildirimler:** muayene, sigorta, kasko, MTV ve hatırlatıcılar için 30, 7 ve 1 gün önce ve günü geldiğinde 09:00'da bildirim gelir. Bildirimler cihazda planlanır; sunucu kurulumu gerekmez.
- **Kaza tutanağı:** PDF olarak kaydetme, yazdırma ve paylaşma; kameradan fotoğraf çekme; konum ekleme.
- **Dosyalar ve paylaşım:** "Verilerimi indir" ve "Takvime aktar" telefonun kendi paylaşım menüsünden kaydedilir. Paylaş butonları da bu menüyü açar.
- **Gezinme ve görünüm:** Android geri tuşu, uygulama içi tarayıcı (e-Devlet, TÜVTÜRK, GİB), titreşimli geri bildirim, temaya uyan durum çubuğu ve açılış ekranı.
- **İnternet yokken:** "Bağlantı yok" ekranı gösterilir; bağlantı geri gelince uygulama kendiliğinden devam eder.

---

## 1) Klasör yapısı

| Klasör / dosya | Ne işe yarar |
|---|---|
| `codemagic.yaml` | Bulut derleme tarifi (iOS + Android). **Deponun kökünde** durmalı. |
| `capacitor.config.json` | Uygulama kimliği, site adresi, eklenti ayarları |
| `android/` | Android Studio projesi (izinler, bildirim ikonu, imzalama) |
| `ios/` | Xcode projesi (izin metinleri, yalnızca iPhone, dikey ekran) |
| `assets/` | Kaynak ikon ve açılış görselleri (`npm run assets` ile yeniden üretilir) |
| `www/index.html` | İnternet yokken gösterilen ekran |

> Bu klasör **sunucuya (public_html) yüklenmez**. Önceden `public_html/mobile` altında duruyorsa oradan silin; GitHub deposunda tutun.

## 2) GitHub deposu

1. GitHub'da **özel (private)** bir depo açın (ör. `aracta-mobile`).
2. Bu klasörün **içeriğini** deponun köküne yükleyin. Kökte `codemagic.yaml`, `package.json`, `android/` ve `ios/` görünmeli.
3. `node_modules`, `.jks` ve parola dosyaları `.gitignore` sayesinde depoya girmez. Anahtar dosyasını **asla** depoya eklemeyin.

## 3) Codemagic ile derleme (Mac gerekmez)

[codemagic.io](https://codemagic.io) adresinde GitHub hesabınızla giriş yapın, **Add application** ile depoyu seçin. Proje tipi olarak *codemagic.yaml* kullanılacak.

### iOS (App Store / TestFlight)

1. **Apple Developer Program** üyeliği gerekir (yıllık ücretli). Şirket adına yayınlanacaksa üyelik "Organization" olarak açılmalı.
2. developer.apple.com → *Certificates, IDs & Profiles* → *Identifiers* → **+** → App ID: `com.aracta.app` (ek yetenek seçmeyin).
3. appstoreconnect.apple.com → *Uygulamalar* → **+ Yeni Uygulama**: platform iOS, ad **Araçta**, ana dil Türkçe, Bundle ID `com.aracta.app`, SKU `aracta-ios`.
4. App Store Connect → *Kullanıcılar ve Erişim* → *Entegrasyonlar* → **App Store Connect API** → *Ekip Anahtarları* → yeni anahtar (erişim: **App Manager**).
   `.p8` dosyasını indirin; **Issuer ID** ve **Key ID** değerlerini not edin.
5. Codemagic → *Team settings* → *Team integrations* → **Developer Portal** → *Connect*.
   Anahtar adı olarak tam olarak **`Aracta ASC`** yazın (codemagic.yaml bu adı kullanır), Issuer ID, Key ID ve `.p8` dosyasını girin.
6. Codemagic → *Team settings* → *codemagic.yaml settings* → *Code signing identities*:
   - *iOS certificates* → **Generate certificate** → tür **Apple Distribution**.
   - developer.apple.com → *Profiles* → **+** → **App Store Connect** → App ID `com.aracta.app` → az önce üretilen sertifikayı seçin → kaydedin.
   - Codemagic'e dönüp *iOS provisioning profiles* → **Fetch profiles** → `com.aracta.app` profilini seçip ekleyin.
7. Uygulama sayfasında **Start new build** → iş akışı **iOS · App Store (TestFlight)**.
   Derleme 15–25 dakika sürer ve bittiğinde TestFlight'a kendiliğinden yüklenir.

### Android (Google Play)

1. Codemagic → *Code signing identities* → *Android keystores* → **Add keystore**:
   `aracta-upload.jks` dosyasını seçin, referans adını **`aracta_upload`** yapın; parolaları `aracta-upload-anahtar-bilgileri.txt` dosyasından girin.
2. **Start new build** → iş akışı **Android · Google Play (AAB)** → bitince *Artifacts* bölümünden `app-release.aab` dosyasını indirin.
3. Play Console'da uygulamayı oluşturup bu `.aab` dosyasını yükleyin (adımlar aşağıda). İlk yüklemeden sonra Google Play App Signing kendiliğinden açılır.

> **Android Studio ile yerelde derleme (isteğe bağlı):** `npm ci` → `npx cap sync android` → `npx cap open android`.
> `android/keystore.properties` dosyası oluşturup `storeFile=../aracta-upload.jks`, `storePassword=…`, `keyAlias=aracta`, `keyPassword=…` satırlarını yazın,
> `.jks` dosyasını `android/` içine koyun ve **Build → Generate Signed App Bundle** deyin.

Sürüm numaraları: mağaza sürümü **1.0.0**. Derleme numarası Codemagic'te her derlemede kendiliğinden artar.
Yeni bir mağaza sürümü için `ios/App/App.xcodeproj/project.pbxproj` içindeki `MARKETING_VERSION` ve `android/app/build.gradle` içindeki `versionName` değerlerini yükseltin.

---

## 4) Mağaza kayıt bilgileri (kopyala-yapıştır)

| Alan | Değer |
|---|---|
| Uygulama adı | Araçta |
| iOS alt başlık (≤30) | Bakım, muayene ve sigorta |
| Play kısa açıklama (≤80) | Aracının bakım, muayene, sigorta, MTV ve masraflarını tek yerden takip et. |
| Kategori | iOS: Yardımcı Programlar (ikincil: Yaşam Tarzı) · Play: Otomobil ve Araçlar |
| Gizlilik politikası | https://aracta.com.tr/#/yasal/gizlilik |
| Destek / iletişim | https://aracta.com.tr/#/iletisim |
| Hesap silme (Play) | https://aracta.com.tr/#/yasal/hesap-silme |
| Yaş derecelendirmesi | iOS 4+ · Play: anketi yanıtlayın (şiddet/kumar yok) → PEGI 3 |
| Hedef kitle (Play) | 18 yaş ve üzeri |

**Uzun açıklama (öneri):**
Araçta; bakım, muayene, trafik sigortası, kasko, MTV ve HGS tarihlerini tek uygulamada toplar. Aracını bir kez ekle; yaklaşan tarihler için bildirim al, harcamalarını ve gerçek yakıt tüketimini gör.
Kaza anında adım adım tutanak doldur, fotoğraf, kroki ve imzaları ekle, PDF olarak paylaş. Gösterge panelindeki uyarı ışıklarının anlamını öğren, yol yardımına tek dokunuşla ulaş, anlaşmalı firmalardaki ayrıcalıkları yakala. Motosikletler için sürüş öncesi kontrol listesi ve sezon rehberi de var.

**App Review notu (iOS, "App Review Information" alanı):**
> Demo hesap: (aşağıda açacağınız e-posta) / (şifre). Hesapta örnek bir araç, hatırlatıcılar, giderler ve bir kaza tutanağı bulunur.
> Bildirimler cihazda yerel olarak planlanır (Profil → Telefon bildirimleri). Konum yalnızca kullanıcı "Konumumu bul / Konumumu ekle" dediğinde, kamera yalnızca kaza tutanağına fotoğraf eklerken kullanılır.
> Hesap silme: Profil → Hesabı sil.

**Apple – Uygulama Gizliliği (App Privacy) yanıtları.** İzleme (tracking) yok; tüm veriler kullanıcıya bağlı ve yalnızca "Uygulama İşlevselliği" amacıyla:
- İletişim bilgileri: Ad, E-posta, Telefon
- Konum: Kesin konum (yalnızca talep veya tutanak için, isteğe bağlı)
- Kullanıcı içeriği: Fotoğraflar, Diğer kullanıcı içeriği (araç, gider ve tutanak kayıtları)
- Tanımlayıcılar: Kullanıcı kimliği

**Google Play – Veri güvenliği (Data safety) yanıtları:**
- Toplanan veriler: Ad, e-posta, telefon, yaklaşık ve kesin konum (isteğe bağlı), fotoğraflar, diğer kullanıcı içeriği.
- Paylaşım: Kasko, parça ve çekici talebi oluşturulduğunda ad, telefon, e-posta ve (çekicide) konum ilgili iş ortağına iletilir. Bu "Paylaşılıyor – Uygulama işlevselliği" olarak işaretlenmeli.
- Aktarım sırasında şifreleme: **Evet** (HTTPS). Kullanıcı veri silme isteyebilir: **Evet** (uygulama içi + yukarıdaki URL).

**Ekran görüntüleri:** `magaza-gorselleri` klasöründeki hazır görseller kullanılabilir.
- iPhone 6,9 inç: 1320×2868
- Android telefon: 1080×1920
- Play öne çıkan görsel: 1024×500 (ayrıca hazırlanmalı)
- Play uygulama ikonu: 512×512 (`assets/icons/icon-512.png`)

---

## 5) Göndermeden önce kontrol listesi

- [ ] **"Örnek …" kampanyalarını** yönetim panelinden gerçekleriyle değiştirin ya da pasif yapın. Apple, yer tutucu içeriği "tamamlanmamış uygulama" diye reddeder.
- [ ] Apple ve Google incelemesi için bir **demo hesap** açın; bir araç, birkaç hatırlatıcı, gider ve bir tutanak ekleyin.
- [ ] Sunucuda `config.php` → `const APP_URL = 'https://aracta.com.tr';` yazın. Şifre sıfırlama ve QR kupon bağlantıları hep doğru alan adını kullanır.
- [ ] Sunucudan `kurulum.php` dosyasını ve `public_html/mobile` klasörünü silin.
- [ ] TestFlight'tan (iOS) ve Play Console'daki **dahili test** sürümünden (Android) gerçek telefonda deneyin: giriş, bildirim izni, kamera, konum, PDF, geri tuşu, çıkış.
- [ ] **Google Play kişisel hesap** kullanıyorsanız (13 Kasım 2023'ten sonra açılmış): üretime çıkmadan önce **en az 12 test kullanıcısıyla 14 gün kesintisiz kapalı test** zorunludur. Kurumsal (organizasyon) hesapta bu şart yoktur.
- [ ] İsteğe bağlı: App Store Connect → *Fiyatlandırma ve Erişilebilirlik* bölümünde "Apple Silicon Mac'lerde kullanılabilir" seçeneğini kapatabilirsiniz.

## 6) Sonraki güncellemeler

- **Görünüm ve özellik değişiklikleri (web):** dosyaları sunucuya yükleyin. `core.php` içindeki `APP_VERSION` değerini her seferinde artırın ki telefonlar eski dosyaları önbellekten kullanmasın.
- **Uygulama kabuğu değişiklikleri (bu klasör):** GitHub'a gönderin → Codemagic'te yeniden derleyin → mağazaya yeni sürüm olarak gönderin.
